# vimetronome

vimetronome blinks a cursor at the given rate in Beats Per Minute

Usage:

    vimetronome <bpm>

## Running from source

1. `poetry install`
2. ```
   poetry shell
   vimetronome 80
   ```
   -or-
   ```
   poetry run vimetronome 80
   ```


