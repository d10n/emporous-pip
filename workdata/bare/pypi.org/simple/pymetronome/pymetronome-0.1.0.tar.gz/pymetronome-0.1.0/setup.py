# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['pymetronome']

package_data = \
{'': ['*']}

install_requires = \
['colored>=1.4.4,<2.0.0', 'docopt>=0.6.2,<0.7.0', 'schema>=0.7.5,<0.8.0']

entry_points = \
{'console_scripts': ['pymetronome = pymetronome.cli:main']}

setup_kwargs = {
    'name': 'pymetronome',
    'version': '0.1.0',
    'description': 'Example package for demonstration',
    'long_description': '# pymetronome\n\npymetronome blinks a cursor at the given rate in Beats Per Minute\n\nUsage:\n\n    pymetronome <bpm>\n\n## Running from source\n\n1. `poetry install`\n2. ```\n   poetry shell\n   pymetronome 80\n   ```\n   -or-\n   ```\n   poetry run pymetronome 80\n   ```\n\n\n',
    'author': 'd10n',
    'author_email': 'd10n@redhat.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
